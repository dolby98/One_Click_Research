from django.apps import AppConfig


class IrbConfig(AppConfig):
    name = 'irb'
