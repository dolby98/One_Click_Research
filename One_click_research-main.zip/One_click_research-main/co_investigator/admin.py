from django.contrib import admin

# Register your models here.
from co_investigator.models import Co_Investigator

admin.site.register(Co_Investigator)