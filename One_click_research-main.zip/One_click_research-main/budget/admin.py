from django.contrib import admin

# Register your models here.
from .models import *


admin.site.register(Budget)
admin.site.register(Consumable)
admin.site.register(Investigation1)
admin.site.register(Investigation2)
admin.site.register(Capital_equip)
admin.site.register(Salaryy)
admin.site.register(Research_fellow)
admin.site.register(Material)
admin.site.register(Other)

