from django.contrib import admin

# Register your models here.
from co_guide.models import Co_Investigator

admin.site.register(Co_Investigator)