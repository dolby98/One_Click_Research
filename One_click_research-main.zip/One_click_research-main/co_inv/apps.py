from django.apps import AppConfig


class GuideConfig(AppConfig):
    name = 'co_inv'
