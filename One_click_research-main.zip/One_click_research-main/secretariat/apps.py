from django.apps import AppConfig


class SecretariatConfig(AppConfig):
    name = 'secretariat'
