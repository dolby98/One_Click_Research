from django.contrib import admin
from .models import sec_details
# Register your models here.

admin.site.register(sec_details)