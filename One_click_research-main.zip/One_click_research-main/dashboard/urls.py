from django.contrib import admin
from django.urls import path, include
from . import views
urlpatterns = [
    # path('student/home/', views.student_dashboard, name='student_dashboard'),
    # path('student/profile/', views.student_profile, name='student_profile'),
    # path('student/budget/', views.sample_create_view, name='student_budget'),
    # path('student/project_details/', views.student_project_details, name='student_project_details'),
    # path('student/completion_report/', views.student_completion_report, name='student_completion_report'),

    # path('guide/home/', views.guide_dashboard, name='guide_dashboard'),
    # path('guide/profile/', views.guide_profile, name='guide_profile'),
    # path('guide/student/', views.guide_student, name='guide_student'),

    # path('director/home/', views.director_dashboard, name='director_dashboard'),
    # path('director/profile/', views.director_profile, name='director_profile'),
    # path('director/student_details/', views.director_student_details, name='director_student_details'),
    # path('director/project_details/', views.director_project_details, name='director_project_details'),
    # path('director/guide_details/', views.director_guide_details, name='director_guide_details'),
    # path('director/secretariat_details/', views.director_secretariat_details, name='director_secretariat_details'),

    # path('secretariat/home/', views.secretariat_dashboard, name='secretariat_dashboard'),
    # path('secretariat/profile/', views.secretariat_profile, name='secretariat_profile'),
    # path('secretariat/director_review/', views.secretariat_director_review, name='secretariat_director_review'),
    # path('secretariat/irb_review/', views.secretariat_irb_review, name='secretariat_irb_review'),
    # path('secretariat/final_review/', views.secretariat_final_review, name='secretariat_final_review'),

]