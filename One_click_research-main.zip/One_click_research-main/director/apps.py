from django.apps import AppConfig


class DirectorConfig(AppConfig):
    name = 'director'
