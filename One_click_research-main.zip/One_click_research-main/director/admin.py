from django.contrib import admin

# Register your models here.
from director.models import Director_details

admin.site.register(Director_details)