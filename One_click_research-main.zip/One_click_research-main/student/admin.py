from django.contrib import admin
from .models import Std_details, Document

# Register your models here.


admin.site.register(Std_details)
admin.site.register(Document)